# TRACE

Code, assembled data and numerical results for **Transition-Regime Attribution and Calibrated Extrapolation (TRACE)**. The repository contains one implementation of the demographic scaffold and statistical models, plus scripts for the descriptive ODE flow analysis and supplementary performance summaries.

## Contents

| Location | Contents |
| --- | --- |
| `data/data.csv` | Supplied assembled transition dataset; input for full training. |
| `data/frozen_analysis_dataset.csv.gz` | Prepared 2,748-transition, 36-site dataset used by the saved analyses. |
| `src/trace_model.py` | Model fitting, grouped evaluation, calibration and statistical procedures. |
| `src/settings.py` | Full analysis configuration and seeds. |
| `scripts/train.py` | Complete model fitting and evaluation. |
| `scripts/reproduce.py` | Rebuild figures and supplemental results from the saved fitted results. |
| `scripts/ode_flows.py` | Standardized ODE trajectories, cumulative fluxes and site-omission sensitivity. |
| `scripts/supplemental.py` | Baseline-state performance and temporal-validation summaries. |
| `scripts/schematic.py` | Model architecture figure. |
| `results/tables/` | Numerical source tables, evaluation results and saved predictions. |
| `results/flows/` | Climate profiles, trajectories, rates, cumulative fluxes and sensitivity summaries. |
| `results/checkpoints/ode_fits.csv` | 37 descriptive ODE fits and the separate deployment-core reference, including all climate-transform arrays. |
| `results/figures/` | All paper figures, with the filenames below. |

Tables printed in the manuscript are formatted views of these CSV data. Separate rendered tables, LaTeX table fragments and an additional spreadsheet are not needed. The three large prediction tables and the complete trajectory table use lossless gzip compression; `pandas.read_csv` reads them directly.

## Environment

Use Python 3.12 on Linux or macOS, or Linux through WSL on Windows. The model's runtime diagnostics use the Unix `resource` module. No GPU is required.

For figure regeneration and the descriptive ODE analysis:

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

`requirements.txt` records the environment used for the descriptive ODE analysis. `requirements-original.txt` records the relevant packages from the original comprehensive training environment. Use a separate Python 3.12 environment with `requirements-original.txt` when attempting to reproduce that historical full training run. Different numerical-library versions, BLAS implementations and hardware may change fitted parameters, rounding or image rendering; fixed random seeds do not imply byte-identical fitted results across environments.

## Reproduce from the supplied results

Run from the repository root:

```bash
python scripts/reproduce.py
```

This rebuilds all nine figure stems, reruns the ODE integrations from the supplied checkpoints, and recreates baseline-state and temporal summaries. It reads the original fitted-result CSV files; it does **not** retrain the original predictive models or recalculate their bootstrap intervals. The saved predictive tables remain the historical numerical source for the paper.

To repeat the 37 descriptive ODE fits as well:

```bash
python scripts/reproduce.py --refit-ode
```

The original run of these 37 fits took approximately 196 seconds; runtime depends on the machine. The leave-one-site-out fits retain original site identities when constructing the variance-weight cross-fitting folds.

## Full fitting order

To recompute the predictive analysis from the assembled input, run these steps in order:

```bash
python scripts/train.py
python scripts/ode_flows.py --force-refit
python scripts/supplemental.py
python scripts/schematic.py
```

The first command uses the full configuration in `src/settings.py`, including nested grouped model selection, six outer folds, Monte Carlo prediction, temporal tests and the original bootstrap diagnostics. The archived comprehensive run took about **101 hours**. Full training was not repeated when assembling this repository. It writes the same CSV and predictive-figure paths used by the supplied results; the remaining three commands write the ODE results, supplementary summaries and architecture figure to their matching paths. No model binaries or JSON files are needed by this workflow.

These commands overwrite the corresponding result files. Keep the supplied historical results in a separate checkout if both the archived and newly fitted outputs are required. After training on changed data, always use `--force-refit`; the checkpoint reader checks the prepared-data content hash and fitting-configuration hash.

## Figure filenames

| File in `results/figures/` | Numerical source or producer |
| --- | --- |
| `observed_predicted.png` | `oof_predictions.csv.gz` |
| `regime_skill_ci.png` | `transition_regimes.csv` |
| `coverage.png` | `interval_calibration.csv` |
| `discrepancy_gradient_sensitivity.png` | `derivative_summary.csv` |
| `residual_qq.png` | `oof_predictions.csv.gz` |
| `ode_identifiability_svd.png` | `ode_singular_values.csv` |
| `stochastic_sensitivity_crps_comparison.png` | `distribution_diagnostics.csv` |
| `ode_climate_flows.pdf`, `ode_climate_flows.png` | `results/flows/trajectory_sensitivity_summary.csv` |
| `pipeline_revised.pdf`, `pipeline_revised.png` | `scripts/schematic.py` |

Source tables in this list are in `results/tables/` unless otherwise stated. The PNG files retain the names used in the paper. The ODE and architecture figures additionally have vector PDF versions.

## Numerical results and interpretation

- Predictive comparisons: `model_metrics.csv`, `paired_model_comparisons.csv`, `component_evidence.csv`, `site_equal_metrics.csv`, `transition_regimes.csv` and `baseline_regime_metrics.csv`.
- Calibration and probabilistic evaluation: `interval_calibration.csv`, `distribution_diagnostics.csv`, `occurrence_metrics.csv`, `calibration_stability.csv` and related detailed CSV files.
- Temporal evaluation: `forward_temporal_validation.csv`, `spatiotemporal_validation.csv`, `forward_temporal_exact.csv` and `spatiotemporal_summary.csv`.
- ODE interpretation: `results/flows/climate_profiles.csv`, `endpoint_flows_all_refits.csv`, `paired_profile_contrasts.csv`, `trajectory_sensitivity_summary.csv` and `scenario_summary.csv`.
- Diagnostics and sensitivity: the remaining numerical tables retain the original fitting, split, support, parameter, solver and derivative diagnostics. The complete core output-name contract is `CORE_TABLES` in `src/paths.py`.

The ODE comparisons hold initial densities and duration fixed and vary observed joint climate profiles. They are conditional scaffold scenarios, not site forecasts or causal climate effects. Site-omission ranges describe sensitivity under the fixed ODE structure and bounds; they are not confidence intervals and do not establish parameter identifiability. All 37 descriptive fits place the feedback parameter at its lower bound. The descriptive 36-site fit is distinct from the archived deployment scaffold fitted to 23 core sites.

The historical 500-refit ODE bootstrap is retained for reproducibility of the original results and saved-rate reconstruction. Its repeated-site relabeling can permit original-site overlap in internal variance-weight folds; those draws do not define the descriptive flow bands. The site-omission analysis preserves original site identities.

The dataset is an assembled analysis table. Raw NEON/Daymet download and linkage scripts and individual-stem histories are not included. Reproduction therefore begins at the supplied assembled data.

## GitHub upload

Upload the contents of this directory while retaining its folder structure. There are no required external model files or Git LFS objects. Generated caches and local environment folders are excluded by `.gitignore`. The [GitHub web uploader](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository) accepts files up to 25 MiB each and up to 100 files per batch. The largest file here is below 8 MiB. This repository contains more than 100 files, so use Git, GitHub Desktop or multiple web-upload batches. Upload the extracted contents, not the ZIP archive itself.
