#!/usr/bin/env python3
"""Fit the complete TRACE analysis and export the repository result files."""
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
import argparse
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from trace_model import *
from paths import DATA, RESULTS, CORE_TABLES, write_table
from settings import FULL_CONFIGURATION


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=DATA / "data.csv")
    args = parser.parse_args()
    start = time.time()
    data_path = args.data.resolve()
    out = RESULTS
    out.mkdir(parents=True, exist_ok=True)
    config = Configuration(**FULL_CONFIGURATION)
    data = prepare_data(data_path)
    frozen_data_path = DATA / "frozen_analysis_dataset.csv.gz"
    data.to_csv(frozen_data_path, index=False, compression={"method": "gzip", "mtime": 0})
    print(f"{len(data)} transitions | {data.plotID.nunique()} plots | {data.siteID.nunique()} sites | profile={config.profile}")
    evaluation = run_outer_cv(data, config)
    leakage = evaluation["Detailed_Leakage_Audit"]
    rbf_unit = evaluation["RBF_Unit_Test"]
    if not leakage.empty and not bool((leakage.status == "PASS").all()):
        raise RuntimeError("Final leakage audit contains at least one FAIL result")
    if not rbf_unit.empty and not bool(rbf_unit["pass"].astype(bool).all()):
        raise RuntimeError("RBF mathematical-to-code unit test failed")
    oof = evaluation["OOF_Predictions"]
    metrics = model_metrics_table(oof, config)
    paired = paired_model_comparisons(oof, config)
    folds = fold_metrics(oof)
    sites = grouped_skill(oof, "siteID")
    site_equal = site_equal_metrics(oof)
    horizon = horizon_skill(oof)
    ood = ood_analysis(oof)
    applicability_continuous = applicability_continuous_analysis(oof, config)
    duration_continuous = duration_continuous_analysis(oof, config)
    site_sample_size = site_sample_size_analysis(oof)
    extreme_sensitivity = extreme_response_sensitivity(oof)
    regimes = transition_regime_analysis(oof, config)
    occurrence = occurrence_metrics(oof)
    reliability = occurrence_reliability(oof)
    occurrence_calibration = occurrence_calibration_summary(oof)
    support_sensitivity = zero_origin_support_sensitivity(oof, config)
    support_audit = transition_support_audit(data, config)
    calibration = interval_calibration_diagnostics(oof, config)
    distribution = distribution_diagnostics(oof, config)
    pit_bins = pit_cluster_bins(oof, config)
    residual = residual_diagnostics(oof, config)
    variance_diagnostics = variance_residual_diagnostics(oof)
    derivative = derivative_summary(evaluation["OOF_Derivatives"], config)
    contribution = contribution_evidence(oof, metrics, paired)
    point_estimators = point_estimator_analysis(oof, config)
    realized_baseline = realized_vs_baseline_comparison(oof, config)
    climate = summarize_climate_rates(evaluation["Fold_Climate_Rates"])
    stability = parameter_stability(evaluation["Fold_Parameters"])
    surrogate_terms, surrogate_audit = fit_sparse_discrepancy_surrogate(oof, config)
    repeated = run_repeated_holdouts(data, config)
    repeated_frequency = repeated_holdout_site_frequency(repeated)
    temporal = run_temporal_validation(data, config)
    spatiotemporal = run_spatiotemporal_validation(data, config)
    final_model, final_calibration, final_prediction, final_split, final_tuning = fit_final_deployment(data, config)
    selected_model, selected_calibration, selected_prediction, selected_split, selected_specification, selected_tuning = fit_final_selected_deployment(data, config, cached_full=(final_model.hyper, final_tuning))
    identifiability = ode_identifiability(final_model.scaffold, data, config, final_calibration.stochastic)
    weak_direction = ode_weak_direction_analysis(final_model, data, config)
    ode_bootstrap = site_bootstrap_scaffold(data, final_model.scaffold, config) if final_model.scaffold is not None else {"draws": pd.DataFrame(), "summary": pd.DataFrame(), "rates": pd.DataFrame(), "rate_summary": pd.DataFrame()}
    derivative_bootstrap_draws, derivative_bootstrap_summary = derivative_bootstrap_stability(data, primary_spec(), final_model.hyper, config)
    numerical = numerical_audit(final_model, data, evaluation["CV_Audit"], config)
    projection_audit = ode_projection_audit(final_model.scaffold, data, config)
    solver_comparison = ode_solver_comparison(final_model.scaffold, data, config)
    optimizer_audit = scaffold_optimizer_multistart_audit(data, config, final_model.scaffold)
    mc_convergence = mc_convergence_audit(final_model, final_calibration, data, config)
    calibration_stability = calibration_stability_analysis(data, config)
    runtime = time.time() - start
    summary = build_summary(data, metrics, site_equal, runtime)
    descriptive = descriptive_statistics(data[[column for column in REQUIRED if column in data.columns] + ["target_year", "u0_log", "v0_log", "u1_log", "v1_log", "delta_u_log", "delta_v_log", "log_dt"]])
    site_descriptive = site_descriptive_statistics(data)
    zero_descriptive = zero_transition_statistics(data)
    data_dictionary = data_role_dictionary(data)
    predictor_audit = predictor_availability_audit(data, final_model.spec, final_model.discrepancy.transform.feature_names)
    availability = feature_availability_table(data)
    data_quality = data_quality_audit(data)
    missingness = missingness_audit(data)
    filter_flow = filter_flow_table(data)
    final_parameters = final_model.scaffold.parameter_table("final_full") if final_model.scaffold is not None else pd.DataFrame()
    final_rates = climate_rate_response(final_model.scaffold, "final_full") if final_model.scaffold is not None else pd.DataFrame()
    final_hessian = final_model.discrepancy.mean_abs_hessian_pairs(data.iloc[: min(len(data), config.derivative_reference_rows)].reset_index(drop=True), raw_scale=True)
    selected_parameters = selected_model.scaffold.parameter_table("final_selected") if selected_model.scaffold is not None else pd.DataFrame()
    tables = {
        "Summary": summary,
        "Model_Metrics": metrics,
        "Paired_Model_Comparisons": paired,
        "Component_Evidence": contribution,
        "Point_Estimator_Metrics": point_estimators["metrics"],
        "Point_Estimator_Paired": point_estimators["paired"],
        "Point_Estimator_Site": point_estimators["site"],
        "Point_Estimator_Regime": point_estimators["regime"],
        "Realized_vs_Baseline": realized_baseline,
        "Transition_Regimes": regimes,
        "Transition_Support_Audit": support_audit,
        "Zero_Origin_Support_Sensitivity": support_sensitivity,
        "Repeated_Holdouts": repeated,
        "Repeated_Holdout_Site_Frequency": repeated_frequency,
        "Forward_Temporal_Validation": temporal,
        "Spatiotemporal_Validation": spatiotemporal,
        "Fold_Metrics": folds,
        "Site_Skill": sites,
        "Site_Equal_Metrics": site_equal,
        "Horizon_Skill": horizon,
        "Duration_Continuous": duration_continuous,
        "Site_Sample_Size": site_sample_size,
        "Extreme_Response_Sensitivity": extreme_sensitivity,
        "OOD_Analysis": ood,
        "Applicability_Continuous": applicability_continuous,
        "Interval_Calibration": calibration,
        "Calibration_Stability": calibration_stability["summary"],
        "Calibration_Stability_Detail": calibration_stability["detail"],
        "Calibration_Stability_Site": calibration_stability["site"],
        "MC_Convergence": mc_convergence,
        "Distribution_Diagnostics": distribution,
        "PIT_Cluster_Bins": pit_bins,
        "Residual_Diagnostics": residual,
        "Variance_Residual_Diagnostics": variance_diagnostics,
        "Occurrence_Metrics": occurrence,
        "Occurrence_Reliability": reliability,
        "Occurrence_Calibration_Summary": occurrence_calibration,
        "TRACE_Tuning": evaluation["TRACE_Tuning"],
        "TRACE_Selected_Tuning": evaluation["TRACE_Selected_Tuning"],
        "TRACE_Specification_Selection": evaluation["TRACE_Specification_Selection"],
        "Benchmark_Tuning": evaluation["Benchmark_Tuning"],
        "Model_Selections": evaluation["Model_Selections"],
        "CV_Audit": evaluation["CV_Audit"],
        "Detailed_Leakage_Audit": evaluation["Detailed_Leakage_Audit"],
        "Split_Manifest": evaluation["Split_Manifest"],
        "RBF_Design_Matrix_Audit": evaluation["RBF_Design_Matrix_Audit"],
        "RBF_Unit_Test": evaluation["RBF_Unit_Test"],
        "Stochastic_Fit_Audit": evaluation["Stochastic_Fit_Audit"],
        "Estimation_Weight_Audit": evaluation["Estimation_Weight_Audit"],
        "Parameter_Stability": stability,
        "Climate_Rate_Stability": climate,
        "ODE_Identifiability": identifiability["summary"],
        "ODE_Singular_Values": identifiability["singular_values"],
        "ODE_Weighted_Singular_Values": identifiability["weighted_singular_values"],
        "ODE_Parameter_Correlation": identifiability["parameter_correlation"],
        "ODE_Weighted_Parameter_Correlation": identifiability["weighted_parameter_correlation"],
        "ODE_Parameter_Sensitivity": identifiability["sensitivity"],
        "ODE_Profile_Objective": identifiability["profile_objective"],
        "ODE_Weak_Direction_Vectors": weak_direction["vectors"],
        "ODE_Weak_Direction_Perturbations": weak_direction["perturbations"],
        "ODE_Projection_Audit": projection_audit,
        "ODE_Solver_Comparison": solver_comparison,
        "ODE_Optimizer_Multistart": optimizer_audit,
        "ODE_Bootstrap_Draws": ode_bootstrap["draws"],
        "ODE_Bootstrap_Summary": ode_bootstrap["summary"],
        "ODE_Bootstrap_Rates": ode_bootstrap["rates"],
        "ODE_Bootstrap_Rate_Summary": ode_bootstrap["rate_summary"],
        "OOF_Derivatives": evaluation["OOF_Derivatives"],
        "Derivative_Summary": derivative,
        "OOF_Hessian_Interactions": evaluation["OOF_Hessian_Interactions"],
        "Final_Hessian_Interactions": final_hessian,
        "Derivative_Bootstrap_Draws": derivative_bootstrap_draws,
        "Derivative_Bootstrap_Summary": derivative_bootstrap_summary,
        "Discrepancy_Surrogate_Terms": surrogate_terms,
        "Discrepancy_Surrogate_Audit": surrogate_audit,
        "Descriptive_Statistics": descriptive,
        "Site_Descriptive": site_descriptive,
        "Zero_Transition_Statistics": zero_descriptive,
        "Filter_Flow": filter_flow,
        "Data_Dictionary": data_dictionary,
        "Feature_Availability": availability,
        "Predictor_Availability_Audit": predictor_audit,
        "Data_Quality_Audit": data_quality,
        "Missingness_Audit": missingness,
        "Final_Full_Parameters": final_parameters,
        "Final_Full_Climate_Rates": final_rates,
        "Final_Full_Split": final_split,
        "Final_Full_Tuning": final_tuning,
        "Final_Full_Calibration_Scores": final_calibration.score_table,
        "Final_Full_Stochastic_Audit": final_calibration.stochastic_audit,
        "Final_Full_Weight_Audit": final_model.estimation_weight_audit,
        "Final_Selected_Parameters": selected_parameters,
        "Final_Selected_Split": selected_split,
        "Final_Selected_Specification": selected_specification,
        "Final_Selected_Tuning": selected_tuning,
        "Final_Selected_Calibration_Scores": selected_calibration.score_table,
        "OOF_Predictions": oof,
        "Final_Full_Predictions": final_prediction,
        "Final_Selected_Predictions": selected_prediction,
        "Numerical_Audit": numerical,
    }

    for name, frame in tables.items():
        if slug(name) in CORE_TABLES:
            write_table(slug(name), frame)
    make_figures(oof, regimes, calibration, derivative, residual,
                 identifiability["singular_values"], distribution, out, config)
    print(f"Full analysis completed in {time.time() - start:.1f}s: {out}")
    print("Next: python scripts/ode_flows.py --force-refit")
    print("Then: python scripts/supplemental.py && python scripts/schematic.py")


if __name__ == "__main__":
    main()
