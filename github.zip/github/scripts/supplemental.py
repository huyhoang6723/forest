#!/usr/bin/env python3
"""Baseline-state, zero-to-zero and temporal performance summaries."""
from __future__ import annotations

import argparse
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from paths import TABLES, table_path

import numpy as np
import pandas as pd


def compute(frame: pd.DataFrame, key: str, rng: np.random.Generator, repeats: int) -> dict:
    y = frame[f"{key}1_log"].to_numpy(float)
    pred = frame[f"pred_{key}_log__trace_full_realized_forcing"].to_numpy(float)
    pers = frame[f"pred_{key}_log__persistence"].to_numpy(float)
    sq_model, sq_pers = (pred - y) ** 2, (pers - y) ** 2
    rmse_model, rmse_pers = np.sqrt(sq_model.mean()), np.sqrt(sq_pers.mean())
    result = dict(n_transitions=len(frame), n_sites=frame.siteID.nunique(),
                  trace_rmse=rmse_model, persistence_rmse=rmse_pers,
                  trace_mae=float(np.abs(pred-y).mean()),
                  persistence_mae=float(np.abs(pers-y).mean()),
                  skill=float(1-rmse_model/rmse_pers) if rmse_pers else np.nan,
                  skill_ci_low=np.nan, skill_ci_high=np.nan)
    if rmse_pers:
        site_sums = pd.DataFrame({"site": frame.siteID.astype(str).to_numpy(),
                                  "model": sq_model, "pers": sq_pers}).groupby("site", sort=True).sum()
        values = site_sums[["model", "pers"]].to_numpy(float)
        selected = rng.integers(0, len(values), size=(repeats, len(values)))
        sums = values[selected].sum(axis=1)
        valid = sums[:, 1] > 0
        # Both RMSEs have the same bootstrap transition count, which cancels.
        boot_skill = 1-np.sqrt(sums[valid, 0]/sums[valid, 1])
        result["skill_ci_low"], result["skill_ci_high"] = np.quantile(boot_skill, [0.025, 0.975])
        result["valid_bootstrap_draws"] = int(valid.sum())
    else:
        result["valid_bootstrap_draws"] = 0
    return result


def baseline_main(argv=None) -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--oof", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--bootstrap", type=int, default=5000)
    parser.add_argument("--seed", type=int, default=20260917)
    args = parser.parse_args(argv)
    if args.bootstrap <= 0:
        parser.error("--bootstrap must be positive")
    source = args.oof.resolve()
    data = pd.read_csv(source)
    args.output.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(args.seed)
    rows = []
    for key, stratum in [("u", "Young"), ("v", "Mature")]:
        needed = [f"{key}0_log", f"{key}1_log",
                  f"pred_{key}_log__trace_full_realized_forcing", f"pred_{key}_log__persistence"]
        if not np.isfinite(data[needed].to_numpy(float)).all():
            raise ValueError(f"Nonfinite analysis value in {stratum}")
        if not np.array_equal(data[f"{key}0_log"], data[f"pred_{key}_log__persistence"]):
            raise ValueError(f"Persistence does not equal baseline in {stratum}")
        masks = {
            "Baseline zero": data[f"{key}0_log"] == 0,
            "Baseline positive": data[f"{key}0_log"] > 0,
            "Zero to zero": (data[f"{key}0_log"] == 0) & (data[f"{key}1_log"] == 0),
        }
        for label, mask in masks.items():
            rows.append(dict(stratum=stratum, group=label,
                             **compute(data.loc[mask], key, rng, args.bootstrap)))
    result = pd.DataFrame(rows)
    result.to_csv(args.output / "baseline_regime_metrics.csv", index=False)
    print(result.to_string(index=False))


def temporal_main(argv=None) -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tables", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    paths = [args.tables / "forward_temporal_validation.csv",
             args.tables / "spatiotemporal_validation.csv"]
    forward, spatial = [pd.read_csv(path) for path in paths]
    labels = {"TRACE-full realized-forcing": "Full", "TRACE baseline-available": "Baseline-available"}
    forward["model_short"] = forward.model.map(labels)
    spatial["model_short"] = spatial.model.map(labels)
    if forward.model_short.isna().any() or spatial.model_short.isna().any():
        raise ValueError("Unrecognized model: revise label mapping explicitly")
    forward_columns = ["cutoff", "model_short", "stage", "train_rows", "test_rows", "train_sites", "test_sites", "site_overlap_train_test", "RMSE_log1p", "Persistence_RMSE_log1p", "RMSE_skill"]
    forward[forward_columns].to_csv(args.output / "forward_temporal_exact.csv", index=False)
    summary_rows = []
    for (model, stage), frame in spatial.groupby(["model_short", "stage"], sort=False):
        if frame.repeat.duplicated().any():
            raise ValueError(f"Duplicate repeat for {model}/{stage}")
        if (frame.site_overlap_train_test != 0).any():
            raise ValueError("Spatiotemporal test has overlapping sites")
        summary_rows.append(dict(model=model, stratum=stage, cutoff=frame.cutoff.iloc[0],
                                 repeats=len(frame), positive_repeats=int((frame.RMSE_skill > 0).sum()),
                                 median_skill=frame.RMSE_skill.median(),
                                 min_skill=frame.RMSE_skill.min(), max_skill=frame.RMSE_skill.max(),
                                 min_test_rows=int(frame.test_rows.min()), max_test_rows=int(frame.test_rows.max()),
                                 min_test_sites=int(frame.test_sites.min()), max_test_sites=int(frame.test_sites.max()),
                                 min_train_rows=int(frame.train_rows.min()), max_train_rows=int(frame.train_rows.max())))
    summary = pd.DataFrame(summary_rows)
    summary.to_csv(args.output / "spatiotemporal_summary.csv", index=False)
    print(forward[forward_columns].to_string(index=False))
    print(summary.to_string(index=False))


if __name__ == "__main__":
    baseline_main(["--oof", str(table_path("oof_predictions")), "--output", str(TABLES)])
    temporal_main(["--tables", str(TABLES), "--output", str(TABLES)])
