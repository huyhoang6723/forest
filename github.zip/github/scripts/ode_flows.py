#!/usr/bin/env python3
"""Standardized climate-conditioned ODE trajectories and cumulative fluxes.

The default run uses saved fits. --force-refit repeats the all-site fit and
36 leave-one-original-site-out fits before generating tables and figures.
"""
from __future__ import annotations
import os
os.environ['OPENBLAS_NUM_THREADS'] = '1'
os.environ['OMP_NUM_THREADS'] = '1'
os.environ['MKL_NUM_THREADS'] = '1'
import argparse
import hashlib
import json
import sys
import time
from pathlib import Path
import numpy as np
import pandas as pd
import scipy
from scipy.integrate import solve_ivp
from scipy.special import expit, logit
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from paths import ROOT, DATA, TABLES, FLOW_TABLES as TABLE, FIGURES as FIGURE, CHECKPOINTS as CHECKPOINT, read_table
from settings import FULL_CONFIGURATION
from checkpoints import load_checkpoints, save_checkpoints
import trace_model
INPUT = TABLES
FEATURES = ['clim_tmean_c', 'clim_vpd_mean_kpa', 'log_prcp', 'log_deficit']
PARAMETERS = ['q_intercept','q_PC1','q_PC2','F_intercept','F_PC1','F_PC2',
              'H_intercept','H_PC1','H_PC2','log_rho','log_mu','log_a','log_b']
RATE_NAMES = ['recruitment_q','maturation_F','mature_loss_H']
QUANTITIES = ['young_density', 'mature_density', 'cumulative_input',
              'cumulative_transfer', 'cumulative_young_loss', 'cumulative_mature_loss']
COLORS = ['#286D9A','#5D5D5D','#C4582B']


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_source():
    return trace_model


def snapshot(fit, label, fit_seconds=0., **extra):
    c = fit.climate
    return dict(label=label, parameters=fit.parameters.tolist(),
                scaler_mean=c.scaler.mean_.tolist(), scaler_scale=c.scaler.scale_.tolist(),
                pca_mean=c.pca.mean_.tolist(), pca_components=c.pca.components_.tolist(),
                orientation=c.orientation.tolist(), fit_cost=float(fit.fit_cost),
                converged=bool(fit.fit_success), nfev=int(fit.nfev),
                active_bounds=fit.active_bounds.tolist(), fit_seconds=float(fit_seconds), **extra)


def scores(fit, raw):
    standardized = (np.asarray(raw)-np.asarray(fit['scaler_mean']))/np.asarray(fit['scaler_scale'])
    return (standardized-np.asarray(fit['pca_mean'])) @ np.asarray(fit['pca_components']).T * fit['orientation']


def rates(fit, raw):
    p = np.asarray(fit['parameters'])
    c = scores(fit, raw)
    q = 1e-4+(5.-1e-4)*expit(p[0]+c@p[1:3])
    f = 1e-4+(1.5-1e-4)*expit(p[3]+c@p[4:6])
    h = 1e-4+(1.5-1e-4)*expit(p[6]+c@p[7:9])
    constants = np.exp(p[9:13])
    return np.column_stack([q,f,h,np.broadcast_to(constants,(len(np.atleast_2d(raw)),4))])


def integrate(rate, u0, v0, horizon, times):
    q,f,h,rho,mu,a,b = rate
    def rhs(t,y):
        u,v = y[:2]
        incoming=q+rho*v
        transfer=f*u
        yl=mu*u+a*u*u
        ml=h*v+b*v*v
        return [incoming-transfer-yl,transfer-ml,incoming,transfer,yl,ml]
    sol=solve_ivp(rhs,(0.,horizon),[u0,v0,0.,0.,0.,0.],method='DOP853',t_eval=times,
                  rtol=1e-10,atol=1e-12)
    if not sol.success or not np.all(np.isfinite(sol.y)) or np.min(sol.y)<-1e-10:
        raise RuntimeError('Invalid scenario integration: '+sol.message)
    u,v,inc,tr,yl,ml=sol.y
    residuals=[np.max(np.abs(u-u0-inc+tr+yl)),np.max(np.abs(v-v0-tr+ml)),
               np.max(np.abs(u+v-u0-v0-inc+yl+ml))]
    return sol.y.T, max(residuals), sol.nfev


def reconstruct_saved_bootstrap(data):
    """Exactly recover raw-coordinate affine bounded-logit rate functions.

    These functions reproduce historical fits but are not inferentially repaired.
    They are retained solely as reproducibility artifacts, not plotted as CIs.
    """
    grid=pd.read_csv(INPUT/'ode_bootstrap_rates.csv')
    draw=pd.read_csv(INPUT/'ode_bootstrap_draws.csv')
    median=data[FEATURES].median().to_numpy()
    rows=[]
    error_rows=[]
    for bootstrap,g in grid.groupby('bootstrap',sort=True):
        X=np.zeros((len(g),5)); X[:,0]=1.
        for j,feature in enumerate(FEATURES):
            mask=g.varied_feature.eq(feature).to_numpy()
            X[mask,j+1]=g.loc[mask,'feature_value'].to_numpy()-median[j]
        for k,name in enumerate(RATE_NAMES):
            low,high=1e-4,5. if k==0 else 1.5
            observed=g[name].to_numpy()
            probability=(observed-low)/(high-low)
            if np.any((probability<=0)|(probability>=1)):
                raise RuntimeError('Logit reconstruction hits numerical rate bound')
            coef=np.linalg.lstsq(X,logit(probability),rcond=None)[0]
            reconstructed=low+(high-low)*expit(X@coef)
            error=float(np.max(np.abs(reconstructed-observed)))
            error_rows.append(dict(bootstrap=int(bootstrap),rate=name,max_abs_error=error,
                                   saved_values_checked=len(g)))
            rows.append(dict(bootstrap=int(bootstrap),rate=name,intercept_at_median=coef[0],
                             **{f'coefficient_{feature}':coef[j+1] for j,feature in enumerate(FEATURES)},
                             **{f'center_{feature}':median[j] for j,feature in enumerate(FEATURES)}))
    error_df=pd.DataFrame(error_rows)
    assert error_df.max_abs_error.max()<1e-10
    pd.DataFrame(rows).to_csv(TABLE/'historical_bootstrap_raw_rate_coefficients.csv',index=False)
    error_df.to_csv(TABLE/'historical_bootstrap_reconstruction_audit.csv',index=False)
    return dict(draws=int(grid.bootstrap.nunique()),rate_values_checked=int(error_df.saved_values_checked.sum()),
                maximum_absolute_rate_reconstruction_error=float(error_df.max_abs_error.max()),
                all_saved_fits_report_convergence=bool(draw.groupby('bootstrap').fit_success.first().all()),
                role='historical reproducibility audit only; not used for primary sensitivity bands',
                limitation='Historical bootstrap uniquely labels repeated copies of the same original site, '
                           'permitting original-site overlap across internal variance-weight cross-fit folds. '
                           'It also refits all 36-site resamples, unlike the frozen 23-site deployment core.')


def main(force=False):
    start=time.perf_counter()
    for p in [TABLE,FIGURE,CHECKPOINT]: p.mkdir(parents=True,exist_ok=True)
    m=load_source()
    data=pd.read_csv(DATA/'frozen_analysis_dataset.csv.gz')
    config=m.Configuration(**FULL_CONFIGURATION)
    cache={} if force else load_checkpoints()
    config.scaffold_multistart=4
    config.scaffold_max_nfev=600
    sites=sorted(data.siteID.astype(str).unique())
    seeds={None:2660000,**{site:2660000+(i+1)*1009 for i,site in enumerate(sites)}}
    fits=[]
    for omitted in [None,*sites]:
        label='all_sites' if omitted is None else f'leave_out_{omitted}'
        sample=data if omitted is None else data.loc[data.siteID.ne(omitted)].reset_index(drop=True)
        if label in cache:
            fit=cache[label]
        else:
            begin=time.perf_counter()
            wu,wv,audit=m.cross_fitted_estimation_weights(sample,config,seeds[omitted]+17)
            max_overlap=int(pd.to_numeric(audit.site_overlap,errors='coerce').fillna(0).max())
            assert max_overlap==0
            fitted=m.DemographicScaffold.fit(sample,config,seeds[omitted]+101,
                       sample_weight_young=wu,sample_weight_mature=wv)
            fit=snapshot(fitted,label,time.perf_counter()-begin,omitted_site=omitted,
                         original_sites=int(sample.siteID.nunique()),rows=len(sample),
                         original_site_overlap_in_weight_crossfit=max_overlap,seed=seeds[omitted],
                         multistarts=4,max_nfev=600)
        if not fit['converged']: raise RuntimeError('Fit did not converge: '+label)
        fits.append(fit)
        print(f"{label}: converged, objective={fit['fit_cost']:.6f}, seconds={fit['fit_seconds']:.2f}",flush=True)
    reference=fits[0]
    pd.DataFrame([{k:v for k,v in f.items() if k not in ['parameters','scaler_mean','scaler_scale',
               'pca_mean','pca_components','orientation','active_bounds']}|
               {'active_bounds':sum(f['active_bounds'])} for f in fits]).reindex(columns=[
               'label','fit_cost','converged','nfev','fit_seconds','omitted_site',
               'original_sites','rows','original_site_overlap_in_weight_crossfit',
               'seed','multistarts','max_nfev','active_bounds']).to_csv(TABLE/'refit_audit.csv',index=False)
    pd.DataFrame([{'fit':f['label'],'parameter':name,'estimate_internal':f['parameters'][j],
                   'active_bound':f['active_bounds'][j]}
                  for f in fits for j,name in enumerate(PARAMETERS)]).to_csv(TABLE/'refit_parameters.csv',index=False)
    # Reconstruct frozen deployment reference from its real (23-site) fitting set.
    split=pd.read_csv(INPUT/'final_full_split.csv')
    core_sites=json.loads(split.loc[split.partition.eq('core'),'site_ids'].iloc[0])
    core=data.loc[data.siteID.isin(core_sites)]
    frozen_climate=m.ClimateTransform.fit(core,2026)
    ptab=pd.read_csv(INPUT/'final_full_parameters.csv').set_index('parameter')
    frozen_scaffold=m.DemographicScaffold(frozen_climate,ptab.loc[PARAMETERS,'estimate_internal'].to_numpy(),
                                          96,True,float(ptab.fit_cost.iloc[0]),True,
                                          ptab.loc[PARAMETERS,'active_bound'].to_numpy(),int(ptab.nfev.iloc[0]))
    frozen=snapshot(frozen_scaffold,'frozen_23_site_core',original_sites=len(core_sites),rows=len(core))
    pred=read_table('final_full_predictions').sort_values('row_id')
    ordered=data.sort_values('row_id')
    pu,pv=frozen_scaffold.predict(ordered)
    frozen_err=max(np.max(np.abs(pu-pred.scaffold_u_log)),np.max(np.abs(pv-pred.scaffold_v_log)))
    assert frozen_err<1e-8, frozen_err
    save_checkpoints([*fits,frozen])
    # Profiles depend only on observed climate, not endpoint responses or model gains.
    raw=data[FEATURES].to_numpy()
    climate_scores=scores(reference,raw)
    standardized=(raw-reference['scaler_mean'])/reference['scaler_scale']
    cuts=np.quantile(climate_scores[:,0],[1/3,2/3])
    group=np.digitize(climate_scores[:,0],cuts)
    profiles=[]
    for g,name in enumerate(['Lower PC1','Middle PC1','Upper PC1']):
        indices=np.flatnonzero(group==g)
        subset=data.iloc[indices]
        counts=subset.siteID.value_counts()
        weights=(1./subset.siteID.map(counts)).to_numpy()
        centroid=np.average(standardized[indices],axis=0,weights=weights)
        medoid_index=indices[np.argmin(np.sum((standardized[indices]-centroid)**2,axis=1))]
        row=data.iloc[medoid_index]
        profiles.append(dict(profile_id=g,profile=name,row_id=int(row.row_id),
                             transition_id=str(row.transition_id),source_site=str(row.siteID),
                             PC1=float(climate_scores[medoid_index,0]),PC2=float(climate_scores[medoid_index,1]),
                             group_rows=len(indices),group_sites=int(subset.siteID.nunique()),
                             **{feature:float(row[feature]) for feature in FEATURES},
                             precipitation_mm_year=float(np.expm1(row.log_prcp)),
                             deficit_mm_year=float(np.expm1(row.log_deficit))))
    profiles=pd.DataFrame(profiles)
    profiles.to_csv(TABLE/'climate_profiles.csv',index=False)
    positive=data.loc[data.u0_kha.gt(0)&data.v0_kha.gt(0)]
    u0,v0=positive[['u0_kha','v0_kha']].median().to_numpy()
    horizon=float(data.dt_years.median())
    times=np.linspace(0.,horizon,121)
    trajectory_rows=[]
    rate_rows=[]
    solver_rows=[]
    for fit in [*fits,frozen]:
        profile_rates=rates(fit,profiles[FEATURES].to_numpy())
        for j,profile in profiles.iterrows():
            rate=profile_rates[j]
            result,balance_error,nfev=integrate(rate,u0,v0,horizon,times)
            solver_rows.append(dict(fit=fit['label'],profile_id=j,max_abs_balance_error=balance_error,
                                    solver_nfev=nfev,minimum_state=float(result[:,:2].min())))
            rate_rows.append(dict(fit=fit['label'],profile_id=j,
                       **dict(zip(['q','F','H','rho','mu','a','b'],rate))))
            for t,row in zip(times,result):
                trajectory_rows.append(dict(fit=fit['label'],profile_id=j,time_years=t,**dict(zip(QUANTITIES,row))))
    trajectory=pd.DataFrame(trajectory_rows)
    trajectory.to_csv(TABLE/'trajectories_all_refits.csv.gz',index=False,compression='gzip')
    pd.DataFrame(rate_rows).to_csv(TABLE/'profile_rates.csv',index=False)
    solvers=pd.DataFrame(solver_rows)
    assert solvers.max_abs_balance_error.max()<1e-8
    solvers.to_csv(TABLE/'solver_balance_audit.csv',index=False)
    primary=trajectory.loc[trajectory.fit.eq('all_sites')]
    loo=trajectory.loc[trajectory.fit.str.startswith('leave_out_')]
    summaries=[]
    for (profile_id,t),g in loo.groupby(['profile_id','time_years']):
        center=primary.loc[primary.profile_id.eq(profile_id)&primary.time_years.eq(t)].iloc[0]
        for q in QUANTITIES:
            summaries.append(dict(profile_id=profile_id,time_years=t,quantity=q,all_site_reference=center[q],
                                  leave_one_site_min=g[q].min(),leave_one_site_max=g[q].max(),
                                  leave_one_site_median=g[q].median(),leave_one_site_refits=len(g)))
    summary=pd.DataFrame(summaries)
    summary.to_csv(TABLE/'trajectory_sensitivity_summary.csv',index=False)
    endpoint=trajectory.loc[trajectory.time_years.eq(horizon)].copy()
    endpoint.to_csv(TABLE/'endpoint_flows_all_refits.csv',index=False)
    contrasts=[]
    for low,high in [(0,1),(1,2),(0,2)]:
        for q in QUANTITIES:
            a=endpoint.loc[endpoint.profile_id.eq(low)].set_index('fit')[q]
            b=endpoint.loc[endpoint.profile_id.eq(high)].set_index('fit')[q]
            d=b-a
            leave=d.loc[d.index.str.startswith('leave_out_')]
            contrasts.append(dict(contrast=f'{high}_minus_{low}',quantity=q,
                                  all_site_reference=d['all_sites'],leave_one_site_min=leave.min(),
                                  leave_one_site_max=leave.max(),leave_one_site_positive=int((leave>0).sum()),
                                  leave_one_site_negative=int((leave<0).sum()),refits=len(leave),
                                  frozen_core_reference=d['frozen_23_site_core']))
    contrasts=pd.DataFrame(contrasts)
    contrasts.to_csv(TABLE/'paired_profile_contrasts.csv',index=False)
    historical=reconstruct_saved_bootstrap(data)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':12,'axes.titlesize':12.5,
                         'axes.labelsize':11.5,'legend.fontsize':10.5,'axes.spines.top':False,
                         'axes.spines.right':False,'pdf.fonttype':42,'ps.fonttype':42})
    fig,axes=plt.subplots(3,2,figsize=(8.8,9.6))
    panel_q=['young_density','mature_density','cumulative_input',
             'cumulative_transfer','cumulative_young_loss','cumulative_mature_loss']
    panel_labels=['Young-stratum density','Mature-stratum density','Cumulative input',
                  'Cumulative transfer','Cumulative young loss','Cumulative mature loss']
    panel_formulas=['$U(t)$','$V(t)$',r'$\int_0^t(q+\rho V)\,ds$',r'$\int_0^t FU\,ds$',
                    r'$\int_0^t(\mu U+aU^2)\,ds$',r'$\int_0^t(HV+bV^2)\,ds$']
    for i,(ax,q,title,formula) in enumerate(zip(axes.flat,panel_q,panel_labels,panel_formulas)):
        for j,p in profiles.iterrows():
            s=summary.loc[summary.profile_id.eq(j)&summary.quantity.eq(q)].sort_values('time_years')
            ax.fill_between(s.time_years,s.leave_one_site_min,s.leave_one_site_max,color=COLORS[j],alpha=.12,lw=0)
            ax.plot(s.time_years,s.all_site_reference,color=COLORS[j],lw=2.0)
        ax.set_title(f'({chr(97+i)}) {title}',loc='left',fontweight='semibold',pad=10)
        ax.text(.05 if i>1 else .97,.93,formula,transform=ax.transAxes,
                ha='left' if i>1 else 'right',va='top',fontsize=12,color='#333333')
        ax.set_xlim(0,horizon)
        ax.set_xlabel('Time since baseline (years)')
        ax.set_ylabel(r'$10^3$ stems ha$^{-1}$')
        ax.grid(alpha=.15,lw=.6)
        ax.tick_params(length=3)
        if i>1: ax.set_ylim(bottom=0)
    handles=[Line2D([0],[0],color=COLORS[j],lw=2,label=f"{p['profile']} ({p['source_site']})")
             for j,p in profiles.iterrows()]
    fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.5,.985),ncol=3,frameon=False)
    fig.text(.5,.025,f'Common initial densities: U = {u0:.3f}, V = {v0:.3f} thousand stems/ha.\n'
             'Lines: all-site descriptive fit; shading: range of 36 site-omission refits.',
             ha='center',fontsize=10.5,color='#444444',linespacing=1.5)
    fig.subplots_adjust(left=.105,right=.985,bottom=.12,top=.91,wspace=.34,hspace=.57)
    # Atomic publication prevents readers from observing a partially written image.
    temp_pdf=FIGURE/'ode_climate_flows_pending.pdf'
    temp_png=FIGURE/'ode_climate_flows_pending.png'
    fig.savefig(temp_pdf,bbox_inches='tight')
    fig.savefig(temp_png,dpi=450,bbox_inches='tight')
    from PIL import Image
    with Image.open(temp_png) as check_image:
        check_image.verify()
    temp_pdf.replace(FIGURE/'ode_climate_flows.pdf')
    temp_png.replace(FIGURE/'ode_climate_flows.png')
    plt.close(fig)
    pd.DataFrame([
        {"quantity": "initial_young_density", "value": u0},
        {"quantity": "initial_mature_density", "value": v0},
        {"quantity": "horizon_years", "value": horizon},
        {"quantity": "leave_one_site_refits", "value": len(sites)},
        {"quantity": "maximum_mass_balance_error", "value": solvers.max_abs_balance_error.max()},
        {"quantity": "frozen_core_max_abs_log_error", "value": frozen_err},
        {"quantity": "historical_rate_reconstruction_max_error", "value": historical['maximum_absolute_rate_reconstruction_error']},
    ]).to_csv(TABLE/'scenario_summary.csv',index=False)
    print('Completed:', TABLE, FIGURE, flush=True)
    print(profiles[['profile','source_site',*FEATURES]].to_string(index=False),flush=True)
    print(contrasts.loc[contrasts.contrast.eq('2_minus_0')].to_string(index=False),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--force-refit',action='store_true',help='Overwrite deterministic fit checkpoints')
    main(parser.parse_args().force_refit)
