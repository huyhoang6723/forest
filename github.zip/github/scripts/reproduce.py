#!/usr/bin/env python3
"""Rebuild figures and supplemental analyses using the bundled fitted results."""
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
import argparse
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from paths import RESULTS, read_table
from settings import FULL_CONFIGURATION
from trace_model import Configuration, make_figures


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--refit-ode", action="store_true",
                        help="Repeat the 37 descriptive scaffold fits before plotting")
    args = parser.parse_args()
    config = Configuration(**FULL_CONFIGURATION)
    print("Rebuilding predictive-performance figures from saved numerical results", flush=True)
    make_figures(read_table("oof_predictions"), read_table("transition_regimes"),
                 read_table("interval_calibration"), read_table("derivative_summary"),
                 read_table("residual_diagnostics"), read_table("ode_singular_values"),
                 read_table("distribution_diagnostics"), RESULTS, config)
    command = [sys.executable, str(ROOT / "scripts" / "ode_flows.py")]
    if args.refit_ode:
        command.append("--force-refit")
    subprocess.run(command, check=True, cwd=ROOT)
    for name in ("supplemental.py", "schematic.py"):
        subprocess.run([sys.executable, str(ROOT / "scripts" / name)], check=True, cwd=ROOT)
    print("Completed: results/figures, results/flows, results/tables", flush=True)


if __name__ == "__main__":
    main()
