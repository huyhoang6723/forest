"""Draw the TRACE model architecture and evaluation design."""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

ROOT = Path(__file__).resolve().parents[1] / 'results' / 'figures'
ROOT.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'pdf.fonttype':42})
fig = plt.figure(figsize=(9.6,8.2))
ax = fig.add_axes([.025,.02,.95,.96])
ax.set_xlim(0,10); ax.set_ylim(0,10); ax.axis('off')
ink='#263445'; blue='#32668B'; orange='#AC6030'; green='#427961'

def box(x,y,w,h,title,body,color=blue):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.04,rounding_size=.09',
                               facecolor=color+'0C',edgecolor=color,linewidth=1.1))
    ax.text(x+w/2,y+h-.18,title,ha='center',va='top',fontsize=10.5,fontweight='bold',color=ink)
    ax.text(x+w/2,y+(h-.32)/2,body,ha='center',va='center',fontsize=9.3,color=ink,linespacing=1.45)

def arrow(x1,y1,x2,y2):
    ax.add_patch(FancyArrowPatch((x1,y1),(x2,y2),arrowstyle='-|>',mutation_scale=11,
                               linewidth=1.1,color='#566271',shrinkA=3,shrinkB=3))

ax.text(.02,9.93,'(a) Architecture: all learned components use core sites',ha='left',va='top',
        fontsize=12,fontweight='bold',color=ink)
box(.4,8.53,9.2,1.00,'Inputs and core-fitted preprocessing',
    'Baseline densities, duration, location and sampling support; realized interval climate\nImputation, scaling and climate PCA; predictor set depends on specification')
box(.20,6.79,3.02,1.17,'Demographic scaffold','Young–mature ODE\nScaffold endpoint log-states',blue)
box(3.49,6.79,3.02,1.17,'Cross-fitted teacher','Extra Trees on positive endpoints\nBlend teacher and observed target',orange)
box(6.78,6.79,3.02,1.17,'Occurrence model','Probability of a positive endpoint\nSite-cross-fitted probability calibration',green)
for x in [1.71,5.,8.29]: arrow(x,8.53,x,7.96)
box(.50,4.99,5.86,1.12,'RBF discrepancy and magnitude',
    'Fit mixed-kernel correction to the residual target\nBaseline + gated scaffold change + correction; truncate at zero',blue)
arrow(1.71,6.79,1.71,6.11); arrow(5.,6.79,5.,6.11)
box(.50,3.28,4.12,1.07,'Point prediction','Magnitude, occurrence-weighted or gated rule\nRule and gates selected by grouped inner CV',blue)
box(5.10,3.28,4.38,1.07,'Predictive simulation','Occurrence sampling and positive magnitude\nDuration/count working noise; truncate at zero',green)
arrow(2.54,4.99,2.54,4.35); arrow(5.89,4.99,6.20,4.35)
# Occurrence probabilities feed both endpoint point rules and simulation.
ax.plot([8.29,8.29,9.88,9.88,9.49],[6.79,6.40,6.40,3.82,3.82],color='#566271',lw=1.1)
arrow(9.82,3.82,9.49,3.82)
ax.plot([8.29,8.29,6.63,6.63,4.80,4.80],[6.40,4.65,4.65,4.62,4.62,3.82],color='#566271',lw=1.1)
arrow(4.80,3.82,4.62,3.82)
ax.text(.02,2.87,'(b) Site-excluded evaluation: disjoint roles within every outer fold',
        ha='left',va='top',fontsize=12,fontweight='bold',color=ink)
box(.20,.70,3.02,1.68,'Core sites','Fit preprocessing and models\nGrouped inner CV for tuning and selection\nCross-fitted residuals for noise scales',blue)
box(3.49,.70,3.02,1.68,'Calibration sites','Adjust raw predictive intervals\nUse held-out site-quantile scores\nNo point-model fitting',orange)
box(6.78,.70,3.02,1.68,'Outer-test sites','Evaluate untouched predictions\nPersistence and refitted comparators\nRegimes, coverage and transfer',green)
arrow(3.22,1.54,3.49,1.54); arrow(6.51,1.54,6.78,1.54)
ax.text(5,.22,'Occurrence-probability calibration is distinct from the held-out adjustment of predictive intervals.',
        ha='center',va='center',fontsize=9,color='#53616F')
fig.savefig(ROOT/'pipeline_revised.pdf',bbox_inches='tight')
fig.savefig(ROOT/'pipeline_revised.png',dpi=400,bbox_inches='tight')
plt.close(fig)
print(ROOT)
