"""Read and write ODE checkpoints using scalar CSV columns."""
import gzip
import hashlib
import json
import numpy as np
import pandas as pd
from paths import CHECKPOINTS, DATA
from settings import FULL_CONFIGURATION

ARRAY_SHAPES = {"parameters": (13,), "scaler_mean": (4,), "scaler_scale": (4,),
                "pca_mean": (4,), "pca_components": (2, 4), "orientation": (2,),
                "active_bounds": (13,)}
INTEGER_FIELDS = {"nfev", "original_sites", "rows", "original_site_overlap_in_weight_crossfit",
                  "seed", "multistarts", "max_nfev"}

def data_digest():
    return hashlib.sha256(gzip.decompress((DATA / "frozen_analysis_dataset.csv.gz").read_bytes())).hexdigest()

def configuration_digest():
    settings = dict(FULL_CONFIGURATION, scaffold_multistart=4, scaffold_max_nfev=600)
    return hashlib.sha256(json.dumps(settings, sort_keys=True).encode()).hexdigest()

def flatten(fit):
    record = {key: value for key, value in fit.items() if key not in ARRAY_SHAPES}
    for key, shape in ARRAY_SHAPES.items():
        for index in np.ndindex(shape):
            record[key + "_" + "_".join(map(str, index))] = np.asarray(fit[key])[index]
    record["data_content_sha256"] = data_digest()
    record["configuration_sha256"] = configuration_digest()
    return record

def inflate(record):
    fit = {key: value for key, value in record.items()
           if key not in {"data_content_sha256", "configuration_sha256"} and not any(key.startswith(name + "_") for name in ARRAY_SHAPES)}
    for key, shape in ARRAY_SHAPES.items():
        fit[key] = np.array([record[key + "_" + "_".join(map(str, index))]
                            for index in np.ndindex(shape)], dtype=float).reshape(shape).tolist()
    for key, value in list(fit.items()):
        if not isinstance(value, list) and pd.isna(value):
            fit.pop(key)
        elif key in INTEGER_FIELDS:
            fit[key] = int(value)
    fit.setdefault("omitted_site", None)
    fit["converged"] = str(fit["converged"]).lower() == "true"
    return fit

def load_checkpoints():
    path = CHECKPOINTS / "ode_fits.csv"
    if not path.exists():
        return {}
    frame = pd.read_csv(path, float_precision="round_trip")
    if not frame.data_content_sha256.eq(data_digest()).all():
        raise ValueError("ODE checkpoints do not match the prepared data; run with --force-refit")
    if "configuration_sha256" not in frame or not frame.configuration_sha256.eq(configuration_digest()).all():
        raise ValueError("ODE checkpoint configuration differs; run with --force-refit")
    return {row["label"]: inflate(row) for row in frame.to_dict("records")}

def save_checkpoints(fits):
    CHECKPOINTS.mkdir(parents=True, exist_ok=True)
    pd.DataFrame([flatten(fit) for fit in fits]).to_csv(CHECKPOINTS / "ode_fits.csv", index=False)
