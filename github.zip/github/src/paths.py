"""Repository paths and tabular output conventions."""
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
RESULTS = ROOT / "results"
TABLES = RESULTS / "tables"
FLOW_TABLES = RESULTS / "flows"
FIGURES = RESULTS / "figures"
CHECKPOINTS = RESULTS / "checkpoints"
CORE_TABLES = ('applicability_continuous',
 'benchmark_tuning',
 'calibration_stability',
 'calibration_stability_detail',
 'calibration_stability_site',
 'climate_rate_stability',
 'component_evidence',
 'cv_audit',
 'data_dictionary',
 'data_quality_audit',
 'derivative_bootstrap_draws',
 'derivative_bootstrap_summary',
 'derivative_summary',
 'descriptive_statistics',
 'detailed_leakage_audit',
 'discrepancy_surrogate_audit',
 'discrepancy_surrogate_terms',
 'distribution_diagnostics',
 'duration_continuous',
 'estimation_weight_audit',
 'extreme_response_sensitivity',
 'feature_availability',
 'filter_flow',
 'final_full_calibration_scores',
 'final_full_climate_rates',
 'final_full_parameters',
 'final_full_predictions',
 'final_full_split',
 'final_full_stochastic_audit',
 'final_full_tuning',
 'final_full_weight_audit',
 'final_hessian_interactions',
 'final_selected_calibration_scores',
 'final_selected_predictions',
 'final_selected_specification',
 'final_selected_split',
 'final_selected_tuning',
 'fold_metrics',
 'forward_temporal_validation',
 'horizon_skill',
 'interval_calibration',
 'mc_convergence',
 'missingness_audit',
 'model_metrics',
 'model_selections',
 'numerical_audit',
 'occurrence_calibration_summary',
 'occurrence_metrics',
 'occurrence_reliability',
 'ode_bootstrap_draws',
 'ode_bootstrap_rate_summary',
 'ode_bootstrap_rates',
 'ode_bootstrap_summary',
 'ode_identifiability',
 'ode_optimizer_multistart',
 'ode_parameter_correlation',
 'ode_parameter_sensitivity',
 'ode_profile_objective',
 'ode_projection_audit',
 'ode_singular_values',
 'ode_solver_comparison',
 'ode_weak_direction_perturbations',
 'ode_weak_direction_vectors',
 'ode_weighted_parameter_correlation',
 'ode_weighted_singular_values',
 'ood_analysis',
 'oof_derivatives',
 'oof_hessian_interactions',
 'oof_predictions',
 'paired_model_comparisons',
 'parameter_stability',
 'pit_cluster_bins',
 'point_estimator_metrics',
 'point_estimator_paired',
 'point_estimator_regime',
 'point_estimator_site',
 'predictor_availability_audit',
 'rbf_design_matrix_audit',
 'rbf_unit_test',
 'realized_vs_baseline',
 'repeated_holdout_site_frequency',
 'repeated_holdouts',
 'residual_diagnostics',
 'site_descriptive',
 'site_equal_metrics',
 'site_sample_size',
 'site_skill',
 'spatiotemporal_validation',
 'split_manifest',
 'stochastic_fit_audit',
 'summary',
 'trace_selected_tuning',
 'trace_specification_selection',
 'trace_tuning',
 'transition_regimes',
 'transition_support_audit',
 'variance_residual_diagnostics',
 'zero_origin_support_sensitivity',
 'zero_transition_statistics')
COMPRESSED_TABLES = {'oof_predictions', 'final_selected_predictions', 'final_full_predictions'}

def table_path(name, directory=TABLES):
    suffix = ".csv.gz" if name in COMPRESSED_TABLES else ".csv"
    return Path(directory) / (name + suffix)

def read_table(name, directory=TABLES):
    return pd.read_csv(table_path(name, directory))

def write_table(name, frame, directory=TABLES):
    path = table_path(name, directory)
    path.parent.mkdir(parents=True, exist_ok=True)
    compression = {"method": "gzip", "mtime": 0} if name in COMPRESSED_TABLES else None
    frame.to_csv(path, index=False, compression=compression)
    return path
