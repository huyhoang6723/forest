from pathlib import Path
import importlib.util
import json
import pandas as pd
root=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('trace_final_module', r'/home/tavietton/tavietton/research/TVT/2026/Hoang_Hirose_Ton/code/TRACE_FINAL_COMPREHENSIVE.py')
module=importlib.util.module_from_spec(spec)
import sys
sys.modules[spec.name]=module
spec.loader.exec_module(module)
manifest=json.loads((root/'run_manifest.json').read_text(encoding='utf-8'))
config=module.Configuration.for_profile(manifest['configuration'].get('profile','full'))
for key,value in manifest['configuration'].items():
    if hasattr(config,key): setattr(config,key,value)
oof=pd.read_csv(root/'oof_predictions.csv.gz')
metrics=module.model_metrics_table(oof,config)
paired=module.paired_model_comparisons(oof,config)
regimes=module.transition_regime_analysis(oof,config)
calibration=module.interval_calibration_diagnostics(oof,config)
point=module.point_estimator_analysis(oof,config)
support=module.zero_origin_support_sensitivity(oof,config)
occurrence=module.occurrence_metrics(oof)
reliability=module.occurrence_reliability(oof)
ood=module.ood_analysis(oof)
applicability=module.applicability_continuous_analysis(oof,config)
duration=module.duration_continuous_analysis(oof,config)
extreme=module.extreme_response_sensitivity(oof)
realized=module.realized_vs_baseline_comparison(oof,config)
rebuild=root/'rebuild'
rebuild.mkdir(exist_ok=True)
outputs={'Model_Metrics':metrics,'Paired_Model_Comparisons':paired,'Transition_Regimes':regimes,'Interval_Calibration':calibration,'Point_Estimator_Metrics':point['metrics'],'Point_Estimator_Paired':point['paired'],'Point_Estimator_Site':point['site'],'Point_Estimator_Regime':point['regime'],'Zero_Origin_Support_Sensitivity':support,'Occurrence_Metrics':occurrence,'Occurrence_Reliability':reliability,'OOD_Analysis':ood,'Applicability_Continuous':applicability,'Duration_Continuous':duration,'Extreme_Response_Sensitivity':extreme,'Realized_vs_Baseline':realized}
for name,frame in outputs.items(): frame.to_csv(rebuild/(module.slug(name)+'.csv'),index=False)
print(str(rebuild))
